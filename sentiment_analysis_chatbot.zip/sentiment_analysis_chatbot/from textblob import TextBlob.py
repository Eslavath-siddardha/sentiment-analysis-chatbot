from textblob import TextBlob

def analyze_sentiment(user_message):
    """
    Analyze the sentiment of the user's message.
    Returns 'positive', 'negative', or 'neutral'.
    """
    analysis = TextBlob(user_message)
    if analysis.sentiment.polarity > 0:
        return "positive"
    elif analysis.sentiment.polarity < 0:
        return "negative"
    else:
        return "neutral"

def chatbot_response(user_message):
    """
    Generate a chatbot response based on the sentiment of the user's message.
    """
    sentiment = analyze_sentiment(user_message)
    
    if sentiment == "positive":
        return "I'm glad to hear that! 😊 How can I assist you further?"
    elif sentiment == "negative":
        return "I'm sorry to hear that. 😔 Let me know how I can help you."
    else:
        return "Thank you for sharing. How can I assist you today?"

# Example interaction
if __name__ == "__main__":
    print("Chatbot: Hi! How can I help you today?")
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["exit", "quit"]:
            print("Chatbot: Goodbye! Have a great day!")
            break
        response = chatbot_response(user_input)
        print(f"Chatbot: {response}")